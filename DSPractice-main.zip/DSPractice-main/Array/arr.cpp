# include<stdio.h>
int main(){
	int arr[3][3] ={ {3,4,6},{7,6,4},{1,4,6}
	};
	for (int i=0; i<3; ++i)
	{
		for(int j=0; j<3; ++j){
			printf("%d%d-",i,j);
			printf("%d  ",arr[i][j]);
			
			//換個寫法
			//int arr[3][3] = { {3,4,6},{7,6,4},{1,4,6}}; 
		}
		puts("");
	}
	return 0;
} 
